/*


*/

import renderer.scene.*;
import renderer.scene.primitives.*;

import java.awt.Color;

/**
   A three-dimensional wireframe model of the letter W.


*/
public class W extends Model
{
   /**
      The letter W.
   */
   public W()
   {
      super("W");

      // Create the front face vertices.



      // Create the back face vertices.



      // Create the Color objects.



      // Create the front face line segments.



      // Create the back face line segments.



      // Create the front face to back face line segments.



   }
}
