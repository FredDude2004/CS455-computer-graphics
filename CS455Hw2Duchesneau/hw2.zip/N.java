/*


*/

import renderer.scene.*;
import renderer.scene.primitives.*;

import java.awt.Color;

/**
   A three-dimensional wireframe model of the letter N.


*/
public class N extends Model
{
   /**
      The letter N.
   */
   public N()
   {
      super("N");

      // Create the front face vertices.



      // Create the back face vertices.



      // Create the Color objects.



      // Create the front face line segments.



      // Create the back face line segments.



      // Create the front face to back face line segments.



   }
}
